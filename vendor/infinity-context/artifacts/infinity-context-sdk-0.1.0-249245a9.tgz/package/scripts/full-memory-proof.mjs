#!/usr/bin/env node
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";

const env = process.env;
const baseUrl = env.INFINITY_CONTEXT_URL ?? "http://127.0.0.1:7788";
const token = env.INFINITY_CONTEXT_TOKEN;
const outputPath = env.INFINITY_CONTEXT_PROOF_OUTPUT;
const artifactOutputPath = env.INFINITY_CONTEXT_PROOF_ARTIFACT_OUTPUT;
const outputMode = env.INFINITY_CONTEXT_PROOF_OUTPUT_MODE === "artifact" ? "artifact" : "report";
const packageMetadata = await readPackageMetadata();
const commandName = "infinity-context-full-memory-proof";
const cliArgs = process.argv.slice(2);

if (hasCliFlag(cliArgs, "--help", "-h")) {
  printFullMemoryProofHelp(commandName);
  process.exit(0);
}

if (hasCliFlag(cliArgs, "--version", "-v")) {
  process.stdout.write(`${packageMetadata.packageVersion ?? "0.0.0"}\n`);
  process.exit(0);
}

const {
  buildFullMemoryProofArtifactPolicyFromEnv,
  buildFullMemoryProofArtifact,
  evaluateFullMemoryProofArtifact,
  InfinityContextClient,
  runFullMemoryProof,
} = await import("../dist/index.js");
const policyConfig = proofPolicyConfig(env);
const requireFullMemory = policyConfig.requireFullMemory;

const startedAt = new Date();
const report = await runFullMemoryProof({
  client: new InfinityContextClient({
    baseUrl,
    token: () => token,
    timeoutMs: parsePositiveInteger(env.INFINITY_CONTEXT_PROOF_TIMEOUT_MS) ?? 15_000,
    retryPolicy: { maxAttempts: 2 },
  }),
  runId: env.INFINITY_CONTEXT_PROOF_RUN_ID,
  requireFullMemory,
  pollAttempts: parsePositiveInteger(env.INFINITY_CONTEXT_PROOF_POLL_ATTEMPTS),
  pollDelayMs: parsePositiveInteger(env.INFINITY_CONTEXT_PROOF_POLL_DELAY_MS),
  outboxDrainAttempts: parsePositiveInteger(env.INFINITY_CONTEXT_PROOF_OUTBOX_DRAIN_ATTEMPTS),
  outboxDrainDelayMs: parsePositiveInteger(env.INFINITY_CONTEXT_PROOF_OUTBOX_DRAIN_DELAY_MS),
});
const finishedAt = new Date();
const artifact = buildFullMemoryProofArtifact({
  report,
  startedAt,
  finishedAt,
  metadata: {
    sdk: packageMetadata,
    git: gitMetadata(env),
    runtime: {
      baseUrl,
      requireFullMemory,
      ...(policyConfig.qualityPreset !== undefined
        ? { qualityPreset: policyConfig.qualityPreset }
        : {}),
      ...(env.INFINITY_CONTEXT_PROOF_RUNTIME_PROFILE !== undefined
        ? { profile: env.INFINITY_CONTEXT_PROOF_RUNTIME_PROFILE }
        : {}),
    },
  },
});
const artifactEvaluation = evaluateFullMemoryProofArtifact(artifact, policyConfig.policy);

if (artifactOutputPath !== undefined && artifactOutputPath.trim().length > 0) {
  await writeJsonFile(artifactOutputPath, artifact);
}

const primaryPayload = outputMode === "artifact" ? artifact : report;
const serialized = `${JSON.stringify(primaryPayload, null, 2)}\n`;
if (outputPath === undefined || outputPath.trim().length === 0) {
  process.stdout.write(serialized);
} else {
  const resolvedOutputPath = await writeJsonFile(outputPath, primaryPayload);
  process.stdout.write(`${resolvedOutputPath}\n`);
}

if (!artifactEvaluation.ok) {
  process.stderr.write(`Full memory proof artifact policy failed: ${artifactEvaluation.errors.join("; ")}\n`);
}

if (!report.ok || !artifactEvaluation.ok) {
  process.exitCode = 1;
}

function hasCliFlag(args, ...flags) {
  return args.some((arg) => flags.includes(arg));
}

function printFullMemoryProofHelp(command) {
  process.stdout.write(`Usage: ${command} [--help] [--version]

Runs the full-memory release proof against an Infinity Context service.

Options:
  -h, --help       Show this help without contacting the service.
  -v, --version    Print the package version.

Environment:
  INFINITY_CONTEXT_URL                         Service base URL. Default: http://127.0.0.1:7788
  INFINITY_CONTEXT_TOKEN                       Bearer token for the service.
  INFINITY_CONTEXT_PROOF_OUTPUT                Optional report output JSON path.
  INFINITY_CONTEXT_PROOF_ARTIFACT_OUTPUT       Optional evidence artifact JSON path.
  INFINITY_CONTEXT_PROOF_OUTPUT_MODE           report or artifact. Default: report.
  INFINITY_CONTEXT_PROOF_QUALITY_PRESET        Optional quality preset: lite, durable or full.
  INFINITY_CONTEXT_PROOF_REQUIRE_FULL_MEMORY   Require Postgres/Qdrant/Graphiti/embeddings readiness. Default: true.
  INFINITY_CONTEXT_PROOF_TIMEOUT_MS            Per-request timeout. Default: 15000.
`);
}

function parsePositiveInteger(value) {
  if (value === undefined) {
    return undefined;
  }
  const parsed = Number(value);

  return Number.isInteger(parsed) && parsed > 0 ? parsed : undefined;
}

async function writeJsonFile(path, payload) {
  const resolvedOutputPath = resolve(path);
  await mkdir(dirname(resolvedOutputPath), { recursive: true });
  await writeFile(resolvedOutputPath, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
  return resolvedOutputPath;
}

async function readPackageMetadata() {
  try {
    const text = await readFile(new URL("../package.json", import.meta.url), "utf8");
    const parsed = JSON.parse(text);
    return {
      ...(typeof parsed.name === "string" ? { packageName: parsed.name } : {}),
      ...(typeof parsed.version === "string" ? { packageVersion: parsed.version } : {}),
    };
  } catch {
    return {};
  }
}

function gitMetadata(env) {
  return {
    ...firstString(env, "commitSha", [
      "GITHUB_SHA",
      "VERCEL_GIT_COMMIT_SHA",
      "COMMIT_SHA",
      "GIT_COMMIT",
      "CI_COMMIT_SHA",
      "BUILD_SOURCEVERSION",
    ]),
    ...firstString(env, "branch", [
      "GITHUB_REF_NAME",
      "VERCEL_GIT_COMMIT_REF",
      "BRANCH_NAME",
      "CI_COMMIT_BRANCH",
      "BUILD_SOURCEBRANCHNAME",
    ]),
    ...firstString(env, "repository", [
      "GITHUB_REPOSITORY",
      "VERCEL_GIT_REPO_SLUG",
      "CI_PROJECT_PATH",
      "BUILD_REPOSITORY_NAME",
    ]),
  };
}

function firstString(env, outputKey, keys) {
  const value = keys
    .map((key) => env[key])
    .find((item) => typeof item === "string" && item.trim().length > 0);

  return value === undefined ? {} : { [outputKey]: value };
}

function proofPolicyConfig(env) {
  try {
    return buildFullMemoryProofArtifactPolicyFromEnv(env);
  } catch (error) {
    process.stderr.write(`${errorMessage(error)}\n`);
    process.exit(2);
  }
}

function errorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}
